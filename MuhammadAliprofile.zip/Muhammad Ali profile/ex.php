
<!DOCTYPE html>
<html lang="en-us">
    <head>
    	<title>Muhammad Ali Profile</title>
 <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <!-- stylesheet -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/owl.carousel.css">
        <link rel="stylesheet" href="css/owl.theme.min.css">
        <link rel="stylesheet" href="css/animate.css">
        <link rel="stylesheet" href="css/main.css">

        <!-- google font -->
        <link href='http://fonts.googleapis.com/css?family=Oswald:300,400' rel='stylesheet'>
        <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=PT+Sans' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Roboto+Condensed:400,300' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Oxygen:400,300' rel='stylesheet' type='text/css'>
        <link href="http://fonts.googleapis.com/css?family=Rouge+Script" rel="stylesheet" type="text/css">
        <link href='http://fonts.googleapis.com/css?family=Milonga' rel='stylesheet' type='text/css'>
          <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

    
    </head>
    <body>
<div>
   
</div>
  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
    Open modal
  </button>
   <!-- The Modal -->
  <div class="modal" id="myModal">
    <div class="">
      <div class="">
      
        <!-- Modal Header -->
      
        
        <!-- Modal body -->
        <div class="modal-body">
           <div class="container" id="slider">
  
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
      <div class="item active">
        <img src="img/work1.jpg" alt="Los Angeles" style="width:100%;">
      </div>

      <div class="item">
        <img src="img/work2.jpg" alt="Chicago" style="width:100%;">
      </div>
    
      <div class="item">
        <img src="img/work3.jpg" alt="New york" style="width:100%;">
      </div>

      <div class="item">
        <img src="img/work5.jpg" alt="New york" style="width:100%;">
      </div>
      <div class="item">
        <img src="img/work6.jpg" alt="New york" style="width:100%;">
      </div>
      <div class="item">
        <img src="img/work6.jpg" alt="New york" style="width:100%;">
      </div>
      <div class="item">
        <img src="img/work7.jpg" alt="New york" style="width:100%;">
      </div>
      <div class="item">
        <img src="img/work8.png" alt="New york" style="width:100%;">
      </div>
      <div class="item">
        <img src="img/work9.jpg" alt="New york" style="width:100%;">
      </div>
      <div class="item">
        <img src="img/work10.jpg" alt="New york" style="width:100%;">
      </div>
      <div class="item">
        <img src="img/work11.jpg" alt="New york" style="width:100%;">
      </div>
      <div class="item">
        <img src="img/work12.jpg" alt="New york" style="width:100%;">
      </div>
      <div class="item">
        <img src="img/work13.jpg" alt="New york" style="width:100%;">
      </div>
      <div class="item">
        <img src="img/work14.jpg" alt="New york" style="width:100%;">
      </div>
      <div class="item">
        <img src="img/work15.jpg" alt="New york" style="width:100%;">
      </div>
      <div class="item">
        <img src="img/work16.jpg" alt="New york" style="width:100%;">
      </div>
      <div class="item">
        <img src="img/work17.jpg" alt="New york" style="width:100%;">
      </div>
      <div class="item">
        <img src="img/work18.jpg" alt="New york" style="width:100%;">
      </div>
      <div class="item">
        <img src="img/work19.jpg" alt="New york" style="width:100%;">
      </div>
      <div class="item">
        <img src="img/work20.jpg" alt="New york" style="width:100%;">
      </div>
      <div class="item">
        <img src="img/work21.jpg" alt="New york" style="width:100%;">
      </div>
    </div>

    <!-- Left and right controls -->
  <!--   <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>

    </a> -->
    <div>


</div>
  </div>

</div>
        </div>
        
        <!-- Modal footer -->
      
      </div>
    </div>
  </div>
  
</div>

    

<!-- <script type="text/javascript">
    document.getElementById('slider').style.display="none";
    function show() {
       document.getElementById('slider').style.display="block";
    }
    function hide() {
       document.getElementById('slider').style.display="none";
    }
</script> -->

                <script>
            new WOW().init();
        </script>

        <script src="js/jquery-2.1.3.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery.actual.min.js"></script>
        <script src="js/isotope.pkgd.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/jquery.isonscreen.js"></script>
       
        <script src="js/main.js"></script>

        <script>
            $(document).ready(function(){
                $('.owl-carousel').owlCarousel({
                    loop:true,
                    margin:10,
                    autoplay:true,
                    autoplayTimeout:3000,
                    autoplayHoverPause:true,
                    responsiveClass:true,
                    responsive:{
                            0:{
                                items:1,
                            },
                            600:{
                                items:1,
                            },
                            1000:{
                                items:1,
                            }
                    }
                })
            });
        </script>

    </body>
</html>
