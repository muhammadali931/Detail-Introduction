<?php
if (isset($_POST['submit'])) {
	$name=$_POST['name'];
	$email=$_POST['email'];
	$message=$_POST['message'];

$servername = "localhost";
$username = "root";
$password = "";
$db="muhammad ali";
$conn = new mysqli($servername, $username, $password, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO contact (Name, email, message)".
"VALUES ('$name','$email','$message')";

if(mysqli_query($conn, $sql)){
    ?>
    <script type="text/javascript">
    	alert('Your message send successfully');
    	window.location.href = "index.html";
    </script>
    <?php
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
}

}
?>